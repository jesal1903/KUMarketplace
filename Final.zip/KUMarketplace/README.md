#HOW TO SET UP
- Configure the MySQL database by editing the .env file and setting up the DB.
- Configure the email by editing the .env file.
- Host the server.js file on a node server.
- Host the website.